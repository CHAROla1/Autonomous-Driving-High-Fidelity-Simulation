﻿// Copyright Epic Games, Inc. All Rights Reserved.


#include "MassTrafficVehicleControlInterface.h"

UMassTrafficVehicleControlInterface::UMassTrafficVehicleControlInterface(FObjectInitializer const& InObjectInitializer)
	: UInterface(InObjectInitializer)
{
}
