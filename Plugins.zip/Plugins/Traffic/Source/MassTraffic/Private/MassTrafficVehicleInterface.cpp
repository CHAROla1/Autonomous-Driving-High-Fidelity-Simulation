﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "MassTrafficVehicleInterface.h"

UMassTrafficVehicleInterface::UMassTrafficVehicleInterface(FObjectInitializer const& InObjectInitializer)
	: UInterface(InObjectInitializer)
{
}
