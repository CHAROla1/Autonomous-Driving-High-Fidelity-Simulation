// Copyright Epic Games, Inc. All Rights Reserved.

#include "MassTrafficEvaluateSequenceAnimInstance.h"


UEvaluateSequenceAnimInstance::UEvaluateSequenceAnimInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}